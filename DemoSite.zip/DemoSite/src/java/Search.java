/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import neoinstance.NeoInstance;
import net.sf.json.JSONObject;

/**
 *
 * @author rakshit
 */
public class Search extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
          System.out.println("hello javascript called");
        response.setContentType("text/html;charset=UTF-8");
          System.out.println("javascript called");
         NeoInstance ni = new NeoInstance();
         String name=request.getParameter("q");
         String Email="hardik@marya.com";
         ArrayList<String> JsonSearch=ni.Searching(Email, name);
         String json = new Gson().toJson(JsonSearch);
                      JSONObject json1 = new JSONObject();

        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
              System.out.println("called");
           
//      json.accumulate("Lang", "Java");
//        json.accumulate("Lang", "Dot net");
//        json.accumulate("Lang", "JQuery");
//        json.accumulate("Lang", "PHP");
//        json.accumulate("Lang", "Python");
//        json.accumulate("Lang", "C");
//        json.accumulate("Lang", "C++");
//        json.accumulate("Lang", "ADA");
//        json.accumulate("Lang", "Dbase");
//        json.accumulate("Lang", "Fortan");
            System.out.println("json string"  + json);//.toString());
            response.setContentType("application/json");
       
            response.getWriter().write(json);//.toString());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(Search.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Search.class.getName()).log(Level.SEVERE, null, ex);
        }
          System.out.println("hello  called");
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(Search.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Search.class.getName()).log(Level.SEVERE, null, ex);
        }
          System.out.println("hello javascript1 called");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
