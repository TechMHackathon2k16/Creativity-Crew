/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bhattmongojar.BhattMongoJar;
import connectsql.ConnectSQL1;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import neoinstance.NeoInstance;

/**
 *
 * @author rakshit
 */
public class Register extends HttpServlet {

   
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        response.setContentType("text/html;charset=UTF-8");
        String fname=request.getParameter("firstname");
        String lname=request.getParameter("lastname");
        String passwd=request.getParameter("pass");
        String Email=request.getParameter("email");
        String sex=request.getParameter("gender");
        String dob=request.getParameter("dob");
        String PhoneNo=request.getParameter("tel");
        String Address=request.getParameter("adress");
String dbuser="root";
String dbPasswd="root";
String Dbname="DemoSite";
String TableName1="user";
String TableName2="login";
connectsql.ConnectSQL1 con=new ConnectSQL1();

con.insertProfileData(fname, lname, passwd, Email, Address, PhoneNo, sex, dob, dbuser, dbPasswd, Dbname, TableName1, TableName2);
        
neoinstance.NeoInstance newnode= new NeoInstance();
newnode.createNode(Email, fname, lname);
bhattmongojar.BhattMongoJar bhtobj=new BhattMongoJar();
bhtobj.RegisterMongo(Email);
response.sendRedirect("index.jsp");
    }

  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException | InstantiationException | IllegalAccessException ex) {
            Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException | InstantiationException | IllegalAccessException ex) {
            Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
