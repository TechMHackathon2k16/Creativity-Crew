/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bhattmongojar.BhattMongoJar;
import connectsql.ConnectSQL1;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.http.Cookie;



public class frmLogintoProfile extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        response.setContentType("text/html;charset=UTF-8");
        String DB = "DemoSite";
        String Dbusername = "root";
        String Dbpassword = "root";

        String tableName2 = "login";
        String username = request.getParameter("uname");
        String password = request.getParameter("pass");
        System.out.println(username + password);

        connectsql.ConnectSQL1 abc = new ConnectSQL1();
        boolean flag = abc.authenticate(username, password, Dbusername, Dbpassword, DB, tableName2);
        if (flag) {
            HttpSession session = request.getSession();
            //String username = (String)session.getAttribute("username");
            String userAgent = request.getHeader("User-Agent");
            String Sess_id = session.getId();
            String ipadrs = InetAddress.getLocalHost().toString();
            session.setAttribute("username", username);
            BhattMongoJar bhtobj = new BhattMongoJar();
            bhtobj.sessionSave(username, Sess_id, userAgent, ipadrs);
            //setting session to expiry in 30 mins
            session.setMaxInactiveInterval(1 * 60);
            Cookie userName = new Cookie("user", username);
            userName.setMaxAge(1 * 60);
            response.addCookie(userName);
            response.sendRedirect("profile.jsp?activity=" + username);
            //rs.forward(request, response);
        } else {
            RequestDispatcher rd = getServletContext().getRequestDispatcher("index.jsp");
            PrintWriter out = response.getWriter();
            out.println("<font color=red>Either user name or password is wrong.</font>");
            rd.include(request, response);
            RequestDispatcher rs = request.getRequestDispatcher("SessionCheck.jsp");
            rs.forward(request, response);
        }
//        SCPojo scp = new Helper().getSCPojo(username);
//
//        String followers = scp.getFollowers();
//        List<String> followerNames = scp.getFollowerNames();
//        String following = scp.getFollowing();
//        List<String> followingNames = scp.getFollowingNames();
//        List<String> RecommendedNames = scp.getRecommendedNames();
//
//        request.setAttribute("followers", followers);
//        request.setAttribute("followerNames", followerNames);
//        request.setAttribute("following", following);
//        request.setAttribute("followingNames", followingNames);
//        request.setAttribute("RecommendedNames", RecommendedNames);
//        RequestDispatcher view = getServletContext().getRequestDispatcher("/profile.jsp?activity=" + username);
//        view.forward(request, response);
        //request.setAttribute("activity",username);

        // response.sendRedirect("profile.jsp?activity=" + username);
        //view.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException | InstantiationException | IllegalAccessException ex) {
            Logger.getLogger(frmLogintoProfile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException | InstantiationException | IllegalAccessException ex) {
            Logger.getLogger(frmLogintoProfile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
