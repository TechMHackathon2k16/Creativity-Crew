/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connectsql;

/**
 *
 * @author rakshit
 */
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author Ankit
 */
public class ConnectSQL1 {

    static Connection con = null;

    public static Connection getConnection(String username, String password, String DB) {

        String url = "jdbc:mysql://localhost:3306/" + DB + "?zeroDateTimeBehavior=convertToNull";
        String driver = "com.mysql.jdbc.Driver";

        try {
            Class.forName(driver).newInstance();
            con = DriverManager.getConnection(url, username, password);
            // System.out.println("Connection established");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }

    public void insertProfileData(String fname, String lname, String passwd, String id, String address, String phn_no, String sex, String dob, String Dbusername, String Dbpassword, String DB, String tableName1, String tableName2) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        String fn = fname;
        String ln = lname;
        String pass = passwd;

        String email = id;
        String addr = address;
        String phn = phn_no;
        String gender = sex;
        String birth = dob;

        con = ConnectSQL1.getConnection(Dbusername, Dbpassword, DB);
        try {
            Statement stmt = con.createStatement();
            String query1 = "Insert into " + tableName1 + " (fname,lname,passwd,id,address,phn_no,sex,dob ) values('" + fn + "','" + ln + "','" + pass + "','" + email + "','" + addr + "','" + phn + "','" + gender + "','" + birth + "')";
            String query2 = "Insert into " + tableName2 + " (passwd,id ) values ('" + pass + "','" + email + "')";
            stmt.executeUpdate(query1);
            stmt.executeUpdate(query2);

        } catch (Exception e) {
            throw e;
        }
    }

    public ArrayList<String> selectProfileData(String sessionemail, String username, String password, String DB, String tableName1) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        ArrayList<String> data = new ArrayList();
        con = ConnectSQL1.getConnection(username, password, DB);
        try {

            Statement stmt = con.createStatement();
            String sql = "SELECT fname,lname,id,address,phn_no,sex,dob FROM " + tableName1 + " where id='" + sessionemail + "'";
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String fn = rs.getString("fname");
                String ln = rs.getString("lname");
                String cn = fn + " " + ln;
                String email = rs.getString("id");
                String addr = rs.getString("address");
                String phn = rs.getString("phn_no");
                String gender = rs.getString("sex");
                Date birth = rs.getDate("dob");
                data.add(email);
                data.add(cn);
                data.add(birth.toString());
                data.add(gender);
                data.add(addr);
                data.add(phn);
                System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx JAR");

                for (int i = 0; i < data.size(); i++) {
                    System.out.println(data.get(i));

                }

                System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx JAR");

            }
        } catch (Exception e) {
            throw e;
        }
        return data;
    }

    public void updateProfileData(String fname, String lname, String id, String address, String phn_no, String sex, String dob, String username, String password, String DB, String tableName1) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {

        con = ConnectSQL1.getConnection(username, password, DB);
        try {
            String sql = "update " + tableName1 + " SET fname=?, lname=?,address=?, phn_no=?, sex=?, dob=? WHERE id=?";

            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, fname);
            stmt.setString(2, lname);
            stmt.setString(3, address);
            stmt.setString(4, phn_no);
            stmt.setString(5, sex);
            stmt.setString(6, dob);
            stmt.setString(7, id);

            stmt.executeUpdate();

        } catch (Exception e) {
            throw e;
        }
    }

    public boolean authenticate(String Username, String Pass, String Dbusername, String Dbpassword, String DB, String tableName2) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {

        con = ConnectSQL1.getConnection(Dbusername, Dbpassword, DB);
        try {
            Statement stmt = con.createStatement();
            String sql = "select passwd,id FROM " + tableName2 + " WHERE passwd='" + Pass + "' and id='" + Username + "'";
            ResultSet rs = stmt.executeQuery(sql);

            return rs.next();
        } catch (Exception e) {
            throw e;
        }
    }

    public static void main(String args[]) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {

        ConnectSQL1 abc = new ConnectSQL1();
        //      abc.insertProfileData("hardik", "marya", "qwerty", 22, "hardik@gmail.com", "kailash colony", "9871949911", "Male", "12-12-12", 1);
        abc.selectProfileData("rajat@biala.com", "root", "root", "DemoSite", "user");
//        abc.updateProfileData("Hardik", "Bhatt", "typo", 25, "abc@gmail.com", "Mayur Vihar", "9654879123", "Male", "8-8-8");
//        boolean flag = abc.authenticate("rajat@biala.com", "rajat", "root", "root", "DemoSite", "login");
//        System.out.println(flag);
    }
}
