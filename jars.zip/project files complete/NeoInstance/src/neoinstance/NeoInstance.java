/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neoinstance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author rakshit
 */
public class NeoInstance {

    public Connection connection() throws SQLException, ClassNotFoundException {
        Class.forName("org.neo4j.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:neo4j://localhost:7474/");
        return con;
    }

    static public void createNode(String email, String Fname, String Lname) throws SQLException, ClassNotFoundException {
        Connection con = new NeoInstance().connection();
        HashMap<String, Object> userMap = new HashMap<>();
        userMap.put("Email", email);
        userMap.put("Fname", Fname);
        userMap.put("Lname", Lname);
        Map<String, Object> params = new HashMap<>();
        params.put("1", userMap);
        //  System.out.println(userMap);
        String Query2 = "CREATE CONSTRAINT ON (u:User) ASSERT u.Email IS UNIQUE";
        String query = " CREATE (user:User {1}) ";

        final PreparedStatement statement = con.prepareStatement(query);
        final PreparedStatement statement1 = con.prepareStatement(Query2);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            int index = Integer.parseInt(entry.getKey());
            statement.setObject(index, entry.getValue());
        }

        final ResultSet result = statement.executeQuery();
        final ResultSet result2 = statement1.executeQuery();

    }

    public void CreateRelation(String email1, String email2, String Weight) throws SQLException, ClassNotFoundException {
        Connection con = new NeoInstance().connection();
//Map<String, Object> params = map("1", "Greg", "2", "Jeremy");
        Map<String, Object> params = new HashMap<>();
        params.put("1", email1);
        params.put("2", email2);

        params.put("3", Weight);

        //String query1 = "CREATE INDEX ON :User(Email)";
        String query3 = "CREATE INDEX ON :Subscribe(Status)";
        String query2 = "MATCH (u1:User {Email:{1}}), (u2:User {Email:{2}})" + "CREATE (u1)-[:Subscribe{Status:{3}}]->(u2)";
        //String query2="CREATE (u1:User { Email:{1}}  )-[r:Subscribe{Status:{3}}]->(u2:User { Email:{2}}) " +
//" RETURN r ";

        //final PreparedStatement statement1 = con.prepareStatement(query1);
        final PreparedStatement statement2 = con.prepareStatement(query2);
        final PreparedStatement statement3 = con.prepareStatement(query3);

        for (Map.Entry<String, Object> entry : params.entrySet()) {
            int index = Integer.parseInt(entry.getKey());
            statement2.setObject(index, entry.getValue());
            //  statement1.setObject(index, entry.getValue());
            statement3.setObject(index, entry.getValue());
        }

        //final ResultSet result1 = statement1.executeQuery();
        final ResultSet result3 = statement3.executeQuery();
        final ResultSet result2 = statement2.executeQuery();
    }

    public ArrayList<String> FollowingName(String Email1) throws SQLException, ClassNotFoundException {
        ArrayList<String> FriendList = new ArrayList<>();

        Connection con = new NeoInstance().connection();
        HashMap<String, Object> params = new HashMap<>();
        params.put("1", Email1);

        String query = "MATCH (n { Email:{1}})-[r:Subscribe]->(b) return b.Email as FriendsName ";
        final PreparedStatement statement1 = con.prepareStatement(query);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            int index = Integer.parseInt(entry.getKey());
            statement1.setObject(index, entry.getValue());
        }
        final ResultSet result2 = statement1.executeQuery();
        while (result2.next()) {
            String friendsname = result2.getString("FriendsName");
            FriendList.add(friendsname);

        }
        return FriendList;
    }

    public String Status(String SessionEmail, String FriendEmail) throws SQLException, ClassNotFoundException {
        String Status = " ";
        Connection con = new NeoInstance().connection();
        Map<String, Object> params = new HashMap<>();
        params.put("1", SessionEmail);
        params.put("2", FriendEmail);
        //String query1 = "CREATE INDEX ON :User(Email)";
        String query3 = "CREATE INDEX ON :Subscribe(Status)";
        String query2 = "match (n:User{Email:{1}})-[r:Subscribe]->(b:User{Email:{2}}) return r.Status as Status";
        // final PreparedStatement statement1 = con.prepareStatement(query1);
        final PreparedStatement statement2 = con.prepareStatement(query2);
        final PreparedStatement statement3 = con.prepareStatement(query3);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            int index = Integer.parseInt(entry.getKey());
            statement2.setObject(index, entry.getValue());
            //   statement1.setObject(index, entry.getValue());
            statement3.setObject(index, entry.getValue());
        }
        //final ResultSet result1 = statement1.executeQuery();
        final ResultSet result3 = statement3.executeQuery();
        final ResultSet result2 = statement2.executeQuery();
        while (result2.next()) {
            String F = new String();
            F = result2.getString("Status");
            Status += Status.concat(F);
        }
        Status = Status.replaceAll(" ", "");

        return Status;
    }

    public String Following(String email) throws SQLException, ClassNotFoundException {
        String Following = " ";
        Connection con = new NeoInstance().connection();
        Map<String, Object> params = new HashMap<>();
        params.put("1", email);
        //String query1 = "CREATE INDEX ON :User(Email)";
        String query3 = "CREATE INDEX ON :Subscribe(Status)";
        String query2 = "MATCH (n { Email:{1}})-[r:Subscribe]->()" + "return count(*) as c";
        // final PreparedStatement statement1 = con.prepareStatement(query1);
        final PreparedStatement statement2 = con.prepareStatement(query2);
        final PreparedStatement statement3 = con.prepareStatement(query3);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            int index = Integer.parseInt(entry.getKey());
            statement2.setObject(index, entry.getValue());
            //   statement1.setObject(index, entry.getValue());
            statement3.setObject(index, entry.getValue());
        }
        //final ResultSet result1 = statement1.executeQuery();
        final ResultSet result3 = statement3.executeQuery();
        final ResultSet result2 = statement2.executeQuery();
        while (result2.next()) {
            String F = new String();
            F = result2.getString("c");
            Following += Following.concat(F);
        }
        Following = Following.replaceAll(" ", "");

        return Following;
    }

    public ArrayList<String> FollowersName(String Email1) throws SQLException, ClassNotFoundException {
        ArrayList<String> FriendList = new ArrayList<>();

        Connection con = new NeoInstance().connection();
        HashMap<String, Object> params = new HashMap<>();
        params.put("1", Email1);

        String query = "MATCH (n { Email:{1}})<-[r:Subscribe]-(b)\n"
                + "return b.Email as FollowersName ";
        final PreparedStatement statement1 = con.prepareStatement(query);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            int index = Integer.parseInt(entry.getKey());
            statement1.setObject(index, entry.getValue());
        }
        final ResultSet result2 = statement1.executeQuery();
        while (result2.next()) {
            String friendsname = result2.getString("FollowersName");
            FriendList.add(friendsname);

        }
        return FriendList;
    }

    public String Followers(String email) throws SQLException, ClassNotFoundException {
        String Follower = new String();
        Follower = " ";
        Connection con = new NeoInstance().connection();
        Map<String, Object> params = new HashMap<>();
        params.put("1", email);
        // String query1 = "CREATE INDEX ON :User(Email)";
        String query3 = "CREATE INDEX ON :Subscribe(Status)";
        String query2 = "MATCH (n { Email:{1}})<-[r:Subscribe]-()" + "return count(*) as c";
        //final PreparedStatement statement1 = con.prepareStatement(query1);
        final PreparedStatement statement2 = con.prepareStatement(query2);
        final PreparedStatement statement3 = con.prepareStatement(query3);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            int index = Integer.parseInt(entry.getKey());
            statement2.setObject(index, entry.getValue());
            //  statement1.setObject(index, entry.getValue());
            statement3.setObject(index, entry.getValue());
        }
        //final ResultSet result1 = statement1.executeQuery();
        final ResultSet result3 = statement3.executeQuery();
        final ResultSet result2 = statement2.executeQuery();
        while (result2.next()) {
            String F = new String();
            F = result2.getString("c");
            Follower += Follower.concat(F);
        }
        Follower = Follower.replaceAll(" ", "");
        return Follower;
    }

    public void Unfollow(String email1, String email2, String Weight) throws SQLException, ClassNotFoundException {
        Connection con = new NeoInstance().connection();

        Map<String, Object> params = new HashMap<>();
        params.put("1", email1);
        params.put("2", email2);
        params.put("3", Weight);

        // String query1 = "CREATE INDEX ON :User(Email)";
        String query3 = "CREATE INDEX ON :Subscribe(Status)";
        String query2 = "MATCH (u1:User { Email:{1}})-[rel:Subscribe]->(u2:User { Email:{2}})" + "DELETE rel";
        //String query2="CREATE (u1:User { Email:{1}}  )-[r:Subscribe{Status:{3}}]->(u2:User { Email:{2}}) " +
//" RETURN r ";

        //final PreparedStatement statement1 = con.prepareStatement(query1);
        final PreparedStatement statement2 = con.prepareStatement(query2);
        final PreparedStatement statement3 = con.prepareStatement(query3);

        for (Map.Entry<String, Object> entry : params.entrySet()) {
            int index = Integer.parseInt(entry.getKey());
            statement2.setObject(index, entry.getValue());
            //  statement1.setObject(index, entry.getValue());
            statement3.setObject(index, entry.getValue());
        }

        //final ResultSet result1 = statement1.executeQuery();
        final ResultSet result3 = statement3.executeQuery();
        final ResultSet result2 = statement2.executeQuery();
    }

    public ArrayList<String> Searching(String Email, String name) throws SQLException, ClassNotFoundException {
        ArrayList<String> SearchingList = new ArrayList<>();
        Connection con = new NeoInstance().connection();
//Map<String, Object> params = map("1", "Greg", "2", "Jeremy");
        name = name.concat(".*");
        HashMap<String, Object> params = new HashMap<>();
        params.put("1", name);
        params.put("2", Email);
        String query1 = "MATCH (n:User{Email:{2}})-[:Subscribe]-(b) WHERE b.Email =~ {1} and not (n.Email=b.Email) RETURN b.Email as Email\n"
                + "UNION\n"
                + "MATCH (n:User{Email:{2}}),(b:User) where Not ((n)-[:Subscribe]-(b))And b.Email =~ {1} and not (n.Email=b.Email) RETURN b.Email as Email";
//        params.put("2",Email);
//        String query1="MATCH (n:User{Email:{2}})-[:Subscribe]-(b) WHERE b.Fname =~ {1} and not (n.Email=b.Email) RETURN b.Fname as fname,b.Lname as lname\n" +
//"UNION\n" +
//"MATCH (n:User{Email:{2}}),(b:User) where Not ((n)-[:Subscribe]-(b))And b.Fname =~ {1} and not (n.Email=b.Email) RETURN b.Fname as fname,b.Lname as lname";
//        String query1="MATCH (n:User{Email:{2}})-[:Subscribe]->(b) WHERE b.Fname =~ {1}  RETURN b.Fname as fname,b.Lname as lname";
//        String query2="MATCH (n:User{Email:{2}}),(b:User) where Not ((n)-[:Subscribe]->(b))And b.Fname =~ {1} RETURN b.Fname as fname,b.Lname as lname";
//String query = "select * from item where name LIKE '"+name+"%'";
        final PreparedStatement statement1 = con.prepareStatement(query1);
//final PreparedStatement statement2 = con.prepareStatement(query2);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            int index = Integer.parseInt(entry.getKey());
            statement1.setObject(index, entry.getValue());
            //statement2.setObject(index, entry.getValue());
        }
//final ResultSet result2 = statement2.executeQuery();
        final ResultSet result1 = statement1.executeQuery();
        while (result1.next()) {
            String EmailRetreived = result1.getString("Email");
//    String fname=result1.getString("fname"); String lname=result1.getString("lname");
//    String Completename=fname+" "+lname;
            SearchingList.add(EmailRetreived);

        }
//while(result2.next()){
//    String fname=result2.getString("fname"); String lname=result2.getString("lname");
//    String Completename=fname+" "+lname;
//    SearchingList.add(Completename);
//    

//}
        return SearchingList;

    }

    static public ArrayList<String> MutualFriends(String Email1, String Email2) throws SQLException, ClassNotFoundException {
        ArrayList<String> FriendList = new ArrayList<>();

        Connection con = new NeoInstance().connection();
        HashMap<String, Object> params = new HashMap<>();
        params.put("1", Email1);
        params.put("2", Email2);
        String query = "MATCH pm= (u:User { Email:{1}})-[:Subscribe]->(mf)<-[:Subscribe]-(abc:User{Email:{2}})\n"
                + "RETURN mf.Fname AS fname,mf.Lname as lname,count(DISTINCT pm) AS mutualFriends\n"
                + "ORDER BY mutualFriends DESC";
        final PreparedStatement statement1 = con.prepareStatement(query);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            int index = Integer.parseInt(entry.getKey());
            statement1.setObject(index, entry.getValue());
        }
        final ResultSet result2 = statement1.executeQuery();
        while (result2.next()) {
            String fname = result2.getString("fname");
            String lname = result2.getString("lname");
            int mutualfriends = result2.getInt("mutualFriends");
            String Completename = fname + " " + lname;
            FriendList.add(Completename + "(" + mutualfriends + ")");

        }
        return FriendList;
    }

    public ArrayList<String> RecommendedFriends(String Email) throws SQLException, ClassNotFoundException {
        ArrayList<String> FriendList = new ArrayList<>();

        Connection con = new NeoInstance().connection();
        HashMap<String, Object> params = new HashMap<>();
        params.put("1", Email);
//        String query1="MATCH pm= (u:User { Email: {1} })-[:Subscribe*2]->(other)\n" +
//"where not((other)-[:Subscribe]->()<-[:Subscribe]-(u))\n" +"and not (u.Email=other.Email)\n"+
//                " and NOT ((u)-[:Subscribe]-(other))\n"+
//"RETURN other.Fname AS fname,other.Lname as lname,count(DISTINCT pm) AS mutualFriends\n" +
//"ORDER BY mutualFriends DESC";
//        String query2="match pm =(other)-[:Subscribe]->(a)<-[:Subscribe]-(b)\n" +
//"where b.Email={1} \n" +"return other.Fname as fname, other.Lname as lname, count (distinct a) as mutualFriends\n" +
//"order by mutualFriends desc";
//String query1="match pm =(other)-[:Subscribe]-(a)-[:Subscribe]-(b)\n" +
//"where b.Email={1}and not ((b)-[:Subscribe]-(other))and not(b.Email=other.Email)\n" +
//"return other.Fname as fname, other.Lname as lname, count (distinct a) as mutualFriends\n" +
//"order by mutualFriends desc";     
        String query1 = "match pm =(other)-[:Subscribe]-(a)-[:Subscribe]-(b)\n"
                + "where b.Email={1}and not ((b)-[:Subscribe]-(other)) and not(b.Email=other.Email)\n"
                + "return other.Email as Email, count (distinct a) as mutualFriends\n"
                + "order by mutualFriends desc";
        final PreparedStatement statement1 = con.prepareStatement(query1);
        //final PreparedStatement statement2 = con.prepareStatement(query2);
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            int index = Integer.parseInt(entry.getKey());
            statement1.setObject(index, entry.getValue());
//    statement2.setObject(index, entry.getValue());
        }
        final ResultSet result1 = statement1.executeQuery();
//final ResultSet result2 = statement2.executeQuery();
        while (result1.next()) {
            String Completename = result1.getString("Email");
            // String lname=result1.getString("lname");
            int mutualfriends = result1.getInt("mutualFriends");
            //String Completename=fname+" "+lname;
            FriendList.add(Completename);//+"("+mutualfriends+")");

        }
        return FriendList;
    }
//     

    public static void main(String args[]) throws SQLException, ClassNotFoundException {
        NeoInstance object = new NeoInstance();
        NeoInstance object1 = new NeoInstance();
//        NeoInstance object2 = new NeoInstance();
//        NeoInstance object3 = new NeoInstance();
//        NeoInstance object4 = new NeoInstance();
//        NeoInstance object5 = new NeoInstance();
//        NeoInstance object6 = new NeoInstance();
//        NeoInstance object7 = new NeoInstance();
//        String abc;

//        object7.createNode("suresh@marya.com", "suresh", "marya");
//        object7.createNode("jadoo@bhatt.com", "jadoo", "bhatt");
//        object.createNode("sheela@gmail.com", "sheela", "farmah");
//        object1.createNode("ramu@kaka.com", "ramu", "Bhai");
//        object1.createNode("masterkidster@gmail.com", "Rakshit1","Sakhuja");
//        object2.createNode("sanju@gmail.com", "sanju", "Khanna");
        //object2.CreateRelation("hardik@marya.com", "sheela@gmail.com", "1");
        //object2.CreateRelation("hardik@marya.com", "jadoo@bhatt.com", "1");
        //object2.CreateRelation("hardik@marya.com", "suresh@marya.com", "1");
        //  object2.CreateRelation("hardik@bhatt.com", "hardik@marya.com", "1");
        // object2.CreateRelation("hardik@marya.com", "sheel@gmail.com", "1");
//         object2.CreateRelation("hardik@marya.com", "sheel@gmail.com", "1");
//         object2.CreateRelation("hardik@marya.com", "sheel@gmail.com", "1");
//         object3.CreateRelation("hardik@marya.com", "karan@gmail.com", "3");
//         object3.CreateRelation("sanju@gmail.com", "hardik@marya.com", "1");
//         object3.CreateRelation("sheela@gmail.com", "suresh@marya.com", "1");
//         object3.CreateRelation("rakshitsakhuja@outlook.com", "ramu@kaka.com", "2");
//         object3.CreateRelation("hardik@marya.com", "masterkidster@gmail.com", "2");
        //object3.Unfollow("hardik@marya.com", "hardik@bhatt.com", "3");
//       String abc = object.Following("rakshitsakhuja@outlook.com");
//       System.out.println(abc);
//        abc = object.Followers("rakshitsakhuja@outlook.com");
//       System.out.println(abc);
//ArrayList arr = new ArrayList();    
//arr=object.FollowersName("hardik@marya.com");
//    for (int i = 0; i < arr.size(); i++) 
//     System.out.println(arr.get(i));
//     arr=object.FollowingName("hardik@marya.com");
//    for (int i = 0; i < arr.size(); i++) 
//     System.out.println(arr.get(i));
//         ArrayList arr = new ArrayList();    
//arr=object.Searching("hardik@marya.com","s");
//    for (int i = 0; i < arr.size(); i++) {
//     System.out.println(arr.get(i));}
//   
//    }}
//    }
        String bc = object.Status("rajat@biala.com", "rakshitsakhuja@outlook.com");
        System.out.println("hadgasdgaj" + bc + "yoyo");
        if (bc.equals("")) {
            System.out.println("true");
        }
    }
}
