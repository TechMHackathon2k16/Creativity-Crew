/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bhattmongojar;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Date;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author rakshit
 */
public class BhattMongoJar {

    public static DB Connection() // basic connecion method that returns db object
    {
        try {
            Mongo mongo = new Mongo("localhost", 27017);
            DB db = mongo.getDB("Test");
            return db;
        } catch (Exception e) {
            return null;
        }
    }

    public Boolean RegisterMongo(String email) // during registration , will make 2 documents in 2 collections using the email of the user
    {
        try {
            DB db = BhattMongoJar.Connection();
            DBCollection collection1 = db.getCollection("Session");
            BasicDBObject document = new BasicDBObject();
            document.put("Email", email);
//            
//            

            collection1.createIndex(new BasicDBObject("Email", 1).append("unique", true));
            collection1.insert(document);

            DBCollection collection2 = db.getCollection("History");
            BasicDBObject document2 = new BasicDBObject();
            document2.put("Email", email);
            collection2.createIndex(new BasicDBObject("Email", 1).append("unique", true));
            collection2.insert(document2);

            DBCollection collection3 = db.getCollection("Posts");
            BasicDBObject document3 = new BasicDBObject();
            document3.put("Email", email);
            collection3.createIndex(new BasicDBObject("Email", 1).append("unique", true));
            collection3.createIndex(new BasicDBObject("Posts.Post", 1).append("unique", true));
            BasicDBObject documentDetail2 = new BasicDBObject();
            documentDetail2.put("Post", null);
            document3.put("Posts", documentDetail2);
            collection3.insert(document2);

            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public Boolean preSessionCheck(String email, String Sess_id) // to check for an existing session from the database
    {                                                            // isme session id hata dio params se aur browserid daal dio usse firmatch kara lio aur session equal hai ki nai dekh lio 
        Boolean flag = false;
        try//// HISTORY SE CHK HNA CHAIYE
        {

            DB db = BhattMongoJar.Connection();
            DBCollection table = db.getCollection("History");
            DBObject query = new BasicDBObject();
            query.put("Email", email);
            DBObject projection = new BasicDBObject();
            projection.put("SessionDetails.SessionId", Sess_id);
            //query.put("SessionDetails.SessionId", Sess_id);
            //System.out.println("projectoo:"+ projection);
            //System.out.println("jhgj"+query);
//            

            DBObject result = (DBObject) table.findOne(query, projection);
            System.out.println("hgsajk" + result);
            if (result != null) {
                flag = true;

            }
        } catch (Exception e) {

        }
        return flag;
    }

    public Boolean sessionSave(String email, String Sess_id, String B_id, String ipAddr) //login code ,collections updated and parameters stored in database 
    {
        Boolean flag = false;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        try {
            DB db = BhattMongoJar.Connection();
            DBCollection table = db.getCollection("Session");

            DBObject criteria = new BasicDBObject();
            criteria.put("Email", email);
            DBObject projection = new BasicDBObject();
            projection.put("Logintime", dateFormat.format(date));
            projection.put("SessionId", Sess_id);
            projection.put("IpAdress", ipAddr);
            projection.put("UserAgent", B_id);
            BasicDBObject update = new BasicDBObject();
            update.put("$push", new BasicDBObject("SessionDetails", projection));

            table.update(criteria, update);

            DBCollection collection2 = db.getCollection("History");
            DBObject criteria1 = new BasicDBObject();
            criteria1.put("Email", email);
            DBObject projection1 = new BasicDBObject();
            projection1.put("Logintime", dateFormat.format(date));
            projection1.put("SessionId", Sess_id);
            projection1.put("IpAdress", ipAddr);
            projection1.put("UserAgent", B_id);
            BasicDBObject update1 = new BasicDBObject();
            update1.put("$push", new BasicDBObject("SessionHistory", projection1));

            collection2.update(criteria1, update1, true, true);

            flag = true;
        } catch (Exception e) {

        }
        return flag;
    }

    public Boolean sessionDelete(String email, String Sess_id) //logout code , deletes session and time of logout enteredin historyb collection 
    {
        Boolean flag = false;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        try {

            DB db = BhattMongoJar.Connection();
            DBCollection table = db.getCollection("Session");

            DBObject criteria = new BasicDBObject();
            criteria.put("Email", email);
            criteria.put("SessionDetails.SessionId", Sess_id);
            DBObject projection1 = new BasicDBObject();

            DBObject projection = new BasicDBObject();
            projection.put("SessionId", null);
            projection.put("IpAdress", null);
            projection.put("UserAgent", null);
            projection.put("Logouttime", dateFormat.format(date));
            BasicDBObject update = new BasicDBObject();
            update.put("$set", new BasicDBObject("SessionDetails", projection));
            table.update(criteria, update, true, true);

            DBCollection collection2 = db.getCollection("History");
            DBObject criteria1 = new BasicDBObject();
            criteria1.put("Email", email);
            DBObject projection2 = new BasicDBObject();
            projection2.put("Logouttime", dateFormat.format(date));
            projection2.put("SessionId", Sess_id);
            BasicDBObject update1 = new BasicDBObject();
            update1.put("$push", new BasicDBObject("SessionHistory", projection2));
            collection2.update(criteria1, update1, true, true);

        } catch (Exception e) {
            return false;
        }
        return flag;

    }

    public Boolean postSave(String email, String post) //enter posts into the database
    {
        Boolean flag = false;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();

        try {

            DB db = BhattMongoJar.Connection();
            DBCollection collection = db.getCollection("PTime");
            BasicDBObject b1 = new BasicDBObject();
            BasicDBObject fields = new BasicDBObject("Email", email);
            DBObject d1 = collection.findOne(b1, fields);
            DBObject result;
            DBObject criteria = new BasicDBObject();
            criteria.put("Email", email);
            DBObject projection = new BasicDBObject();
            projection.put("time", dateFormat.format(date));
            projection.put("Post", post);
            BasicDBObject update = new BasicDBObject();
            update.put("$push", new BasicDBObject("Posts", projection));

            collection.update(criteria, update, true, true);
            flag = true;

        } catch (Exception e) {
        }

        return flag;
    }

    public ArrayList<String> postPrint(String email) throws ParseException //print the posts of the user by email
    {                                          //iska return type arraylist<String> rakhu ya String?????

        try {

            DB db = BhattMongoJar.Connection();
            Mongo mongo = new Mongo("localhost", 27017);
//        DB db = mongo.getDB("Test");
//        String email = "ar_aduuta@yahoo.com";
            DBCollection collection = db.getCollection("PTime");
            BasicDBObject b1 = new BasicDBObject();
            BasicDBObject field1 = new BasicDBObject("Email", email);
            BasicDBObject field2 = new BasicDBObject("Posts.Post", 1).append("Posts.time", 1);
            // BasicDBObject field3 = new BasicDBObject("Post", 1);
            DBCursor d1 = collection.find(field1, field2);
            List<String> posts = new ArrayList<String>();
            while (d1.hasNext()) {
                BasicDBObject obj = (BasicDBObject) d1.next();
                String abc = obj.get("Posts").toString();
                //System.out.println(abc);
                JSONParser jp = new JSONParser();
                Object obj1 = jp.parse(abc);
                JSONArray jsonArray = (JSONArray) obj1;
                for (int i = 0; i < jsonArray.size(); i++) {
                    String memberValue = jsonArray.get(i).toString();
                    JSONParser jp1 = new JSONParser();
                    org.json.simple.JSONObject obj2 = (org.json.simple.JSONObject) jp1.parse(memberValue);
                    posts.add("@" + obj2.get("time").toString() + ":\n   " + obj2.get("Post").toString());

                }
            }
            return (ArrayList<String>) posts;
//        System.out.println("********************************");
//        for (Iterator<String> iterator = posts.iterator(); iterator.hasNext();) {
//            String next = iterator.next();
//            System.out.println(next);

//            DBCollection collection = db.getCollection("PostsByTime");
//            BasicDBObject b1 = new BasicDBObject();
//            BasicDBObject fields = new BasicDBObject("Email", email);
//            ArrayList<String> cl1 = (ArrayList<String>) collection.distinct("Posts.Post");
//            ArrayList<String> cl2 = (ArrayList<String>) collection.distinct("Posts.time");
//           ArrayList<String> cl3 = null;
//           for (int i=0;i<cl1.size();i++)
//           {
//               System.out.println(cl1.get(i));
//               System.out.println(cl2.get(i));
//               cl3.add(cl1.get(i));
//           cl3.add(cl2.get(i));}
        } catch (Exception e) {
            return null;
        }

    }

    public ArrayList<String> getSessionData(String email) throws ParseException //what return type to return multiple fields fron History collection???
    {

        DB db = BhattMongoJar.Connection();
        DBCollection collection = db.getCollection("History");
        BasicDBObject b1 = new BasicDBObject();
        BasicDBObject field1 = new BasicDBObject("Email", email);
        BasicDBObject field2 = new BasicDBObject("SessionHistory.Logintime", 1).append("SessionHistory.UserAgent", 1);
        //BasicDBObject field3 = new BasicDBObject("Post", 1);
        DBCursor d1 = collection.find(field1, field2);
        ArrayList<String> Sess = new ArrayList<String>();
        while (d1.hasNext()) {
            BasicDBObject obj = (BasicDBObject) d1.next();
            String abc = obj.get("SessionHistory").toString();

            JSONParser jp = new JSONParser();
            Object obj1 = jp.parse(abc);

            JSONArray jsonArray = (JSONArray) obj1;
            for (int i = 0; i < jsonArray.size(); i++) {
                String memberValue = jsonArray.get(i).toString();

                JSONParser jp1 = new JSONParser();
                org.json.simple.JSONObject obj2 = (org.json.simple.JSONObject) jp1.parse(memberValue);
                try {
                    Sess.add("Broswer :" + obj2.get("UserAgent").toString() + "\n    Since :" + obj2.get("Logintime").toString());
                } catch (Exception e) {
                    continue;
                }

            }
        }
        return Sess;

    }

    public static void main(String[] args) throws UnknownHostException, ParseException {
        Boolean a;
        BhattMongoJar abc = new BhattMongoJar();
//       // a = abc.RegisterMongo("rakshitsakhuja@outlook.com");
////        a = abc.RegisterMongo("hardik@bhatt.com");
////    
//////        System.out.println(a);
//////        a=abc.preSessionCheck("rakshitsakhuja@outlook.com","bowID123" );
//////        if(a==false)
//////	{
////        InetAddress IP = InetAddress.getLocalHost();
////        System.out.println(IP.toString());
////        String ipa = IP.toString();
////        //a = abc.sessionDelete("rakshitsakhuja@outlook.com", "Session123");
////       a = abc.sessionSave("rakshitsakhuja@outlook.com", "Session123","firefox1233",ipa);
////       a = abc.sessionSave("hardik@bhatt.com", "Session1","fir1233",ipa);
////        
////       
////       a = abc.preSessionCheck("hardik@bhatt.com", "Session1");
////        System.out.println(a);
//////	}
////        //a = abc.postSave("rajat@biala.com", "Hi this is my 55 Post");
//	//a=abc.postPrint("ar_aduuta@yahoo.com");
////	a=abc.postSave("ar_aduuta@yahoo.com","Hi this is 1");
////	a=abc.postSave("ar_aduuta@yahoo.com","Hi this is 2t");
//	//a=abc.postSave("rajat@bi","Hi this is 3");
//       // abc.getData("rakshitsakhuja@outlook.com");
        ArrayList arr = new ArrayList();
        arr = abc.getSessionData("ar_aduuta@yahoo.com");
        for (int i = 0; i < arr.size(); i++) {
            System.out.println(arr.get(0));
        }
    }
}
